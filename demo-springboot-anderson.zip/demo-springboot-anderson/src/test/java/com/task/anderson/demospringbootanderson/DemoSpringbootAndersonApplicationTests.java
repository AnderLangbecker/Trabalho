package com.task.anderson.demospringbootanderson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringbootAndersonApplicationTests {

	@Test
	void contextLoads() {
	}

}
