package com.task.anderson.demospringbootanderson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringbootAndersonApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringbootAndersonApplication.class, args);
	}

}
